// 桥接脚本：注入到所有网页，但只在页面按约定 postMessage 时才动作。
// 页面 → 插件：window.postMessage({ source: 'aipdd-page', type: 'distribute' | 'collect' | 'outreach' | ..., payload })
// 插件 → 页面：window.postMessage({ source: 'aipdd-extension', type: 'result' | 'harvest' | 'outreach-result' | 'acq-state', ... })
// 页面侧实现见前端「营销工具 → 多平台内容分发」与「营销工具 → AI 获客」的使用说明。
(() => {
  if (window.__AIPDD_ENTERPRISE_BRIDGE__) return;
  window.__AIPDD_ENTERPRISE_BRIDGE__ = true;

  const post = (payload) => window.postMessage({ source: "aipdd-extension", ...payload }, window.location.origin);

  /** 统一转发到后台并应答：后台不可用（插件被禁用/正在更新）时也要给页面一个明确失败。 */
  async function relay(jobId, message, extra = {}) {
    try {
      const ack = await chrome.runtime.sendMessage(message);
      post({
        type: "accepted",
        jobId: ack?.state?.jobId || jobId,
        ok: Boolean(ack?.ok),
        errorMsg: String(ack?.errorMsg || ""),
        ...extra,
        state: ack?.state || null,
      });
    } catch (error) {
      post({
        type: "accepted",
        jobId,
        ok: false,
        errorMsg: String(error?.message || error),
        ...extra,
        state: null,
      });
    }
  }

  // 页面握手：探测插件是否安装（前端页面据此提示「未检测到插件」）。
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    // 同帧同源护栏：只处理与当前页面 origin 完全一致的发件方，避免 iframe 嵌景伪造握手。
    if (event.origin !== window.location.origin) return;
    const data = event.data;
    if (!data || data.source !== "aipdd-page") return;
    const jobId = String(data.jobId || "");
    const payload = data.payload || {};

    if (data.type === "ping") {
      post({
        type: "pong",
        // 版本直接读 manifest，避免写死后升级插件时握手回报与真实版本脱节。
        version: chrome.runtime.getManifest().version,
      });
      return;
    }

    // 已授权站点：读 / 移除插件本地信任白名单（与 popup 的「信任此站点」共用同一份存储）。
    if (data.type === "trust-list" || data.type === "trust-revoke") {
      try {
        const stored = await chrome.storage.local.get("trustedOrigins");
        const list = Array.isArray(stored?.trustedOrigins) ? stored.trustedOrigins : [];
        if (data.type === "trust-list") {
          post({ type: "trust-list", jobId, ok: true, sites: list });
          return;
        }
        const site = String(payload.site || "").trim();
        const next = list.filter((item) => item !== site);
        await chrome.storage.local.set({ trustedOrigins: next });
        post({ type: "trust-revoke", jobId, ok: true, sites: next });
      } catch (error) {
        post({
          type: data.type,
          jobId,
          ok: false,
          sites: [],
          errorMsg: String(error?.message || error),
        });
      }
      return;
    }

    if (data.type === "distribute") {
      await relay(jobId, {
        type: "AIPDD_DISTRIBUTE",
        jobId,
        payload,
      });
      return;
    }

    // 回执补传：页面连上后拉插件本地队列里的待补结果，落库成功后回执清队。
    if (data.type === "receipts") {
      try {
        const ack = await chrome.runtime.sendMessage({ type: "AIPDD_PENDING_RECEIPTS" });
        post({ type: "receipts", jobId, ok: Boolean(ack?.ok), items: ack?.items || [] });
      } catch (error) {
        post({ type: "receipts", jobId, ok: false, items: [], errorMsg: String(error?.message || error) });
      }
      return;
    }

    if (data.type === "receipts-ack") {
      try {
        await chrome.runtime.sendMessage({
          type: "AIPDD_RECEIPTS_ACK",
          jobIds: Array.isArray(payload.jobIds) ? payload.jobIds : [],
        });
      } catch (_) {
        // 插件被禁用/更新中：清队失败无副作用，下次连上仍会补传（服务端幂等）。
      }
      return;
    }

    // 获客：采集与触达共用同一条启动通道，任务类型由 payload.type 决定，
    // apiBase / token 由页面签发，后台还会校验 apiBase 必须与本页同源。
    if (data.type === "collect" || data.type === "outreach") {
      await relay(jobId, {
        type: "AIPDD_ACQ_START",
        jobId,
        taskType: data.type,
        payload: { ...payload, type: data.type },
      });
      return;
    }

    // 令牌只有 5 分钟：长任务跑到一半由页面重新签发，续期不重启任务、不丢已采到的结果。
    if (data.type === "acq-token") {
      await relay(jobId, { type: "AIPDD_ACQ_TOKEN", token: String(payload.token || "") });
      return;
    }

    if (data.type === "acq-control") {
      const action = String(payload.action || "");
      const type = action === "stop" ? "AIPDD_ACQ_STOP" : action === "pause" ? "AIPDD_ACQ_PAUSE" : "";
      if (!type) {
        post({ type: "accepted", jobId, ok: false, errorMsg: `未知控制动作 ${action}`, state: null });
        return;
      }
      await relay(jobId, { type });
      return;
    }

    if (data.type === "acq-status") {
      await relay(jobId, { type: "AIPDD_ACQ_STATUS" });
      return;
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    // 后台逐平台分发结果 → 转发给页面（携 jobId + contentId，页面据此关联台账并落库）。
    if (message?.type === "AIPDD_RESULT") {
      post({
        type: "result",
        jobId: message.jobId || "",
        contentId: Number(message.contentId) || 0,
        logs: message.logs || [],
      });
      return false;
    }
    // 获客进度/状态 → 原样转发（harvest / outreach-result / acq-state / acq-unknown）。
    if (message?.type === "AIPDD_ACQ_EVENT") {
      const payload = { ...message, type: String(message.event || "acq-state") };
      delete payload.event;
      post(payload);
      return false;
    }
    return false;
  });
})();